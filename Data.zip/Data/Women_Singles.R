############## Scrapping the Women's Singles Data

#### Importing the necesary dependencies
library(rvest)
library(tidyverse)
library(dplyr)

# Base URL 
wurl <- "https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=WS&country=%&page="

# Initializing an empty vector to store the URLs
wurls <- vector("character", length = 48)

# Iterating to construct URLs for the first 48 pages by adding the different page numbers to the base Url
for (i in 1:48) {
  wurls[i] <- paste0(wurl, i, "&pagesize=25&type=unified")
}

###### Storing all the data in table.2 from different pages.
table.2 <- vector()
for (i in 1:48) {
  table.2[i] <- read_html(wurls[i]) %>%
    html_elements("table") %>% 
    html_table(fill = TRUE)
}

#### Combining all the data 
data.3 <- bind_rows(table.2)

#### Scrapping country names seperately
countries.w <- list()
for (i in 1:48) {
  countries.w[[i]] <- read_html(wurls[i]) %>%
    html_elements("img") %>%
    html_attr("title")
}

### Unlisting the country names
unlisted_countries.w <- unlist(countries.w)

## Omittig the NA values
country_w.names <- na.omit(unlisted_countries.w)

## Replacing the "" to independent since we don't know the country names 
Country_w <- as.vector(country_w.names)
for (i in 1:length(country_w.names)) {
  if(country_w.names[i] == ""){
    Country_w[i] <- "Independent"
  }
}

### Final data
women.data <- cbind(data.3, Country_w)
