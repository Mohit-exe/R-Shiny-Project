###################################mixed doubles##############################################

library(rvest)

#base url
mdurl<-"https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=XD&country=%&page="



# Initialize an empty vector to store the URLs

mdurls <- vector("character", length = 59)

# Loop to construct URLs for the first 59 pages

for (i in 1:59) {
  mdurls[i] <- paste0(mdurl, i, "&pagesize=25&totalrows=1459&type=unified")  # Constructing each page URL
}
mdurls

t<-vector()
tables<-vector()
for (i in 1:59) {
  tables[i]<-read_html(mdurls[i]) %>% html_elements("table") %>% html_table(fill = TRUE)
  
}
library(dplyr)
combined_table <- bind_rows(tables)
combined_table

#country names
library(rvest)
countries<-list()
for (i in 1:59) {
  countries[[i]]<-read_html(mdurls[i]) %>% html_elements("img") %>% html_attr("title")
  
}

countries<-unlist(countries)
countries

countries <-na.omit(countries)
country<-countries
country
for (i in 1:length(country)) {
  if(country[i]==""){
    country[i]<-"Independent"
  }
  
}
# Combine consecutive entries with a backslash
combined_country <- paste(country[seq(1, length(country) - 1, by = 2)], 
                          country[seq(2, length(country), by = 2)], 
                          sep = "\\")


combined_table<-combined_table[-c(1458,1459),]
final_table<-cbind(combined_table,combined_country)

final_table

