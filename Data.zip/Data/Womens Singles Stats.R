### Loading the necessary dependencies
library(rvest)
library(tidyverse)
library(dplyr)

base_url <- read_html("https://www.badmintonstatistics.net/Reports")  # URL of the Stats page of the website

report_filters <- base_url %>% html_elements("#reportSelection option")  %>% html_text()  # Report filters available on the page
report_filters <- report_filters[report_filters!="Tournament-Winner Stats"]  #Selecting the required filters

level_filters <- base_url %>% html_elements("#levelSelection option")  %>% html_text() #Level filter available on the page
level_filters <- level_filters[3:4] #Selecting the required filters



# Variables for building the url for each filter selection
reportname = c("PlayerWinsAndLosses","FirstSetWins","FirstSetLosses","MostPointsH2H","PerformanceFollowingWorldChampionship",
               "MostCalendarYearsWithFinal","WeeksInTop10Ranking","MostConsecutiveWeeksTop10BWFRanking","finalsmatches",
               "ThreeSetPercentages")
levelname = c("superseries","grandprix")

#Loop to scrape the data for all combinatations  of above filters
for(k in 1:length(levelname)){ #k iterates over the level filters
  for(j in 1:length(reportname)){ #j iterates over the repor filters
    
    cat(rep("\n", 4))
    print(paste("Starting",level_filters[k],report_filters[j]))
    
    filter1 <- levelname[k]  #Currently selected filters
    filter2 <- reportname[j]
    
    url_part1 <- "https://www.badmintonstatistics.net/Reports?reportname=" #Parts of the URL
    url_part2 <- "&category=WS&year=-1&level="
    url_part3 <- "&country=%"
    base_url_WS <- paste0(url_part1,filter2,url_part2,filter1,url_part3) #URL of the first page of the selcted combination of URLS
    num_pages <- as.numeric(base_url_WS %>% read_html() %>% html_elements("button.pagebutton") %>% html_text() %>% tail(1)) #No of pages to be scraped
    
    tables <- vector(length=num_pages)  #Creating a vector to store the tables from different pages
    
    url1 <- "https://www.badmintonstatistics.net/Reports?page=" #Parts of the URL of each page
    url2 <- "&reportname="
    url3 <- "&category=WS&year=-1&level="
    url4 <- "&country=%" 
    
    for(i in 1:num_pages){ #Iterating over each page
      
      url_WS_filter <- paste0(url1,i,url2,filter2,url3,filter1,url4) #URL of each page

      #Scraping the data of each page
      html_pg <-  read_html(url_WS_filter)
      tables[i] <- html_pg %>% html_elements("table") %>% html_table()

      #Report filter 6 doesnt have countries specified
      if(j!=6){
        Countries <- html_pg %>% html_elements("td") %>% html_element("img") %>% html_attr("title")##html_element("img") %>%
        Countries <- as.vector(na.omit(Countries))
        tables[[i]] <- cbind(tables[[i]],Countries)
      }
      
      #Time interval between every 50 calls
      if(i%%50 == 0){
        Sys.sleep(5)
      }
     
      
      print(paste("Finished iteration",i,level_filters[k],report_filters[j]))
      
    }
    
    table <- bind_rows(tables)  #Final table created by joining all the tables
    name <- paste0("WS_",levelname[k],"_",reportname[j])  #Dynamic naming of table based on filter combinations
    name.RDat <- paste0(name,".RData")
    assign(name,table)
    save(name,file=name.RDat) #Saving the file
    
    Sys.sleep(15)              
  }
  Sys.sleep(30)
}
