####### Scrapping the badmintonstatistics.net website

### Loading the necessary dependencies
library(rvest)
library(tidyverse)
library(dplyr)

# Base URL for Badminton Statistics rankings with placeholders without specifyin the page numbers
base_url <- "https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=MS&country=%&page="

# Initializing an empty vector to store the 72 URLs for all the pages
urls <- vector("character", length = 72)

# Iterating to construct URLs for the first 72 pages by adding the different page numbers to the base Url
for (i in 1:72) 
{
  urls[i] <- paste0(base_url, i, "&pagesize=25&totalrows=1792&type=unified")
}

## Storing all the data from different pages.
table <- vector(length = 72)
for (i in 1:72) {
  table[i] <- read_html(urls[i]) %>% 
    html_elements("table") %>%
    html_table(fill = TRUE)
}

#### Combining all the tables 
data.1 <- bind_rows(table)

#### Scrapping country names seperately
countries.m <- list()
for (i in 1:72) {
  countries.m[[i]] <- read_html(urls[i]) %>%
    html_elements("img") %>%
    html_attr("title")
}

### Since the country names are stored in a list that's why unlisting the whole data
unlisted_countries <- unlist(countries.m)

### Omitting the NA values 
country.names <- na.omit(unlisted_countries)

## Replacing the "" to independent since we don't know the country names 
Country <- as.vector(country.names)
for (i in 1:length(country.names)) {
  if(country.names[i] == ""){
    Country[i] <- "Independent"
  }
}

#### Combining the country data to our main data
mens.data <- cbind(data.1, Country)
mens.data

############## Scrapping the Women's Singles Data

#### Importing the necesary dependencies
library(rvest)
library(tidyverse)
library(dplyr)

# Base URL 
wurl <- "https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=WS&country=%&page="

# Initializing an empty vector to store the URLs
wurls <- vector("character", length = 48)

# Iterating to construct URLs for the first 48 pages by adding the different page numbers to the base Url
for (i in 1:48) {
  wurls[i] <- paste0(wurl, i, "&pagesize=25&type=unified")
}

###### Storing all the data in table.2 from different pages.
table.2 <- vector()
for (i in 1:48) {
  table.2[i] <- read_html(wurls[i]) %>%
    html_elements("table") %>% 
    html_table(fill = TRUE)
}

#### Combining all the data 
data.3 <- bind_rows(table.2)

#### Scrapping country names seperately
countries.w <- list()
for (i in 1:48) {
  countries.w[[i]] <- read_html(wurls[i]) %>%
    html_elements("img") %>%
    html_attr("title")
}

### Unlisting the country names
unlisted_countries.w <- unlist(countries.w)

## Omittig the NA values
country_w.names <- na.omit(unlisted_countries.w)

## Replacing the "" to independent since we don't know the country names 
Country_w <- as.vector(country_w.names)
for (i in 1:length(country_w.names)) {
  if(country_w.names[i] == ""){
    Country_w[i] <- "Independent"
  }
}

### Final data
women.data <- cbind(data.3, Country_w)
#Loading the necessary dependencies
library(rvest)
library(dplyr)
library(rvest)

#base url
mdurl<-"https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=MD&country=%&page="



# Initialize an empty vector to store the URLs
mdurls <- vector("character", length = 52)

# Loop to construct URLs for the first 52 pages
for (i in 1:52) {
  mdurls[i] <- paste0(mdurl, i, "&pagesize=25&totalrows=1298&type=unified")  # Constructing each page URL
}
mdurls

# Storing all the data from different pages.
t<-vector()
tables<-vector()
for (i in 1:52) {
  tables[i]<-read_html(mdurls[i]) %>% html_elements("table") %>% html_table(fill = TRUE)
  
}

# Combining all the tables 
combined_table <- bind_rows(tables)

# Scrapping country names seperately
countries<-list()
for (i in 1:52) {
  countries[[i]]<-read_html(mdurls[i]) %>% html_elements("img") %>% html_attr("title")
  
}

### Since the country names are stored in a list that's why unlisting the whole data
countries<-unlist(countries)

### Omitting the NA values 
countries <-na.omit(countries)
country<-countries

## Replacing the "" to independent since we don't know the country names 
for (i in 1:length(country)) {
  if(country[i]==""){
    country[i]<-"Independent"
  }
  
}

# Combine consecutive entries with a backslash
combined_country <- paste(country[seq(1, length(country) - 1, by = 2)], 
                          country[seq(2, length(country), by = 2)], 
                          sep = "\\")


#### Combining the country data to our main data
combined_table<-combined_table[-1298,]
final_table0<-cbind(combined_table,combined_country)


###################################mixed doubles##############################################

library(rvest)

#base url
mdurl<-"https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=XD&country=%&page="



# Initialize an empty vector to store the URLs

mdurls <- vector("character", length = 59)

# Loop to construct URLs for the first 59 pages

for (i in 1:59) {
  mdurls[i] <- paste0(mdurl, i, "&pagesize=25&totalrows=1459&type=unified")  # Constructing each page URL
}
mdurls

t<-vector()
tables<-vector()
for (i in 1:59) {
  tables[i]<-read_html(mdurls[i]) %>% html_elements("table") %>% html_table(fill = TRUE)
  
}
library(dplyr)
combined_table <- bind_rows(tables)
combined_table

#country names
library(rvest)
countries<-list()
for (i in 1:59) {
  countries[[i]]<-read_html(mdurls[i]) %>% html_elements("img") %>% html_attr("title")
  
}

countries<-unlist(countries)
countries

countries <-na.omit(countries)
country<-countries
country
for (i in 1:length(country)) {
  if(country[i]==""){
    country[i]<-"Independent"
  }
  
}
# Combine consecutive entries with a backslash
combined_country <- paste(country[seq(1, length(country) - 1, by = 2)], 
                          country[seq(2, length(country), by = 2)], 
                          sep = "\\")


combined_table<-combined_table[-c(1458,1459),]
final_table<-cbind(combined_table,combined_country)

final_table

library(rvest)
library(dplyr)
library(rvest)

#base url
mdurl<-"https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=WD&country=%&page="

# Initialize an empty vector to store the URLs
mdurls <- vector("character", length = 39)

# Loop to construct URLs for the first 39 pages
for (i in 1:39) {
  mdurls[i] <- paste0(mdurl, i, "&pagesize=25&totalrows=967&type=unified")  # Constructing each page URL
}

# Storing all the data from different pages.
t<-vector()
tables<-vector()
for (i in 1:39) {
  tables[i]<-read_html(mdurls[i]) %>% html_elements("table") %>% html_table(fill = TRUE)
  
}

# Combining all the tables 
combined_table <- bind_rows(tables)

# Scrapping country names seperately
countries<-list()
for (i in 1:39) {
  countries[[i]]<-read_html(mdurls[i]) %>% html_elements("img") %>% html_attr("title")
  
}

#Since the country names are stored in a list that's why unlisting the whole data
countries<-unlist(countries)

# Omitting the NA values 
countries <-na.omit(countries)
country<-countries
for (i in 1:length(country)) {
  if(country[i]==""){
    country[i]<-"Independent"
  }
  
}

# Combine consecutive entries with a backslash
combined_country <- paste(country[seq(1, length(country) - 1, by = 2)], 
                          country[seq(2, length(country), by = 2)], 
                          sep = "\\")


#### Combining the country data to our main data
combined_table<-combined_table[-c(965,966,967),]
final_table2<-cbind(combined_table,combined_country)
final_table2



rbind.data.frame(final_table,final_table2,mens.data,women.data,final_table0)



