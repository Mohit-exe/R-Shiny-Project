####### Scrapping the badmintonstatistics.net website

### Loading the necessary dependencies
library(rvest)
library(tidyverse)
library(dplyr)

# Base URL for Badminton Statistics rankings with placeholders without specifyin the page numbers
base_url <- "https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=MS&country=%&page="

# Initializing an empty vector to store the 72 URLs for all the pages
urls <- vector("character", length = 72)

# Iterating to construct URLs for the first 72 pages by adding the different page numbers to the base Url
for (i in 1:72) 
  {
     urls[i] <- paste0(base_url, i, "&pagesize=25&totalrows=1792&type=unified")
  }

## Storing all the data from different pages.
table <- vector(length = 72)
for (i in 1:72) {
  table[i] <- read_html(urls[i]) %>% 
    html_elements("table") %>%
    html_table(fill = TRUE)
}

#### Combining all the tables 
data.1 <- bind_rows(table)

#### Scrapping country names seperately
countries.m <- list()
for (i in 1:72) {
  countries.m[[i]] <- read_html(urls[i]) %>%
    html_elements("img") %>%
    html_attr("title")
}

### Since the country names are stored in a list that's why unlisting the whole data
unlisted_countries <- unlist(countries.m)

### Omitting the NA values 
country.names <- na.omit(unlisted_countries)

## Replacing the "" to independent since we don't know the country names 
Country <- as.vector(country.names)
for (i in 1:length(country.names)) {
  if(country.names[i] == ""){
    Country[i] <- "Independent"
  }
}

#### Combining the country data to our main data
mens.data <- cbind(data.1, Country)
