#Loading the necessary dependencies
library(rvest)
library(dplyr)
library(rvest)

#base url
mdurl<-"https://www.badmintonstatistics.net/Rankings?date=2023-10-23&category=MD&country=%&page="



# Initialize an empty vector to store the URLs
mdurls <- vector("character", length = 52)

# Loop to construct URLs for the first 52 pages
for (i in 1:52) {
  mdurls[i] <- paste0(mdurl, i, "&pagesize=25&totalrows=1298&type=unified")  # Constructing each page URL
}
mdurls

# Storing all the data from different pages.
t<-vector()
tables<-vector()
for (i in 1:52) {
  tables[i]<-read_html(mdurls[i]) %>% html_elements("table") %>% html_table(fill = TRUE)
  
}

# Combining all the tables 
combined_table <- bind_rows(tables)

# Scrapping country names seperately
countries<-list()
for (i in 1:52) {
  countries[[i]]<-read_html(mdurls[i]) %>% html_elements("img") %>% html_attr("title")
  
}

### Since the country names are stored in a list that's why unlisting the whole data
countries<-unlist(countries)countries

### Omitting the NA values 
countries <-na.omit(countries)
country<-countries

## Replacing the "" to independent since we don't know the country names 
for (i in 1:length(country)) {
  if(country[i]==""){
    country[i]<-"Independent"
  }
  
}

# Combine consecutive entries with a backslash
combined_country <- paste(country[seq(1, length(country) - 1, by = 2)], 
                          country[seq(2, length(country), by = 2)], 
                          sep = "\\")


#### Combining the country data to our main data
combined_table<-combined_table[-1298,]
final_table<-cbind(combined_table,combined_country)







