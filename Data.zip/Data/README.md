Data on ranking and statistics of badminton players were scraped from the website https://www.badmintonstatistics.net/Index .

