### Loading the necessary dependencies
library(rvest)
library(tidyverse)
library(dplyr)

#### Storing the base url
base_url <- read_html("https://badmintonstatistics.net/Reports?reportname=PlayerWinsAndLosses&category=%&year=2024&level=worldtour&country=%&page=")

# Initializing an empty vector to store the 28 URLs for all the pages
urls <- vector("character", length = 28)

# Iterating to construct URLs for the first 72 pages by adding the different page numbers to the base Url
for (i in 1:28) 
{
  urls[i] <- paste0(base_url, i, "&totalrows=686&sortcolumn=Wins&sortdirection=desc")
}


## Storing all the data from different pages.
table <- vector(length = 28)
for (i in 1:28) {
  table[i] <- read_html(urls[i]) %>% 
    html_elements("table") %>%
    html_table(fill = TRUE)
}

#### Combining all the tables 
match.data <- bind_rows(table)

#### Scrapping country names seperately
countries.match <- list()

for (i in 1:28) {
  countries.match[[i]] <- read_html(urls[i]) %>%
    html_elements("img") %>%
    html_attr("title")
}

### Since the country names are stored in a list that's why unlisting the whole data
unlisted_countries <- unlist(countries.match)

### Omitting the NA values 
country_match.names <- na.omit(unlisted_countries)

