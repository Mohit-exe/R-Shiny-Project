library(tidyverse)
library(dplyr)

# Set the directory path
data_dir <- "../Cleaned_10/"

# List all .RData files in the directory that start with "WS_grandprix"
files <- list.files(path = data_dir, pattern = "data_10.*\\.RData$", full.names = TRUE)



# Load each .RData file
for (file in files) {
  load(file)  
}

MS_ss_data_10 <- MS_ss_data_10 %>% mutate(Tournament = "ss",.before = Category)
WS_ss_data_10 <- WS_ss_data_10 %>% mutate(Tournament = "ss",.before = Category)
MS_gp_data_10 <- MS_gp_data_10 %>% mutate(Tournament = "gp",.before = Category)
WS_gp_data_10 <- WS_gp_data_10 %>% mutate(Tournament = "gp",.before = Category)


final_data_10 <- rbind(MS_ss_data_10,MS_gp_data_10,WS_ss_data_10,WS_gp_data_10)


###############
files <- list.files(path = data_dir, pattern = "H2H_10.*\\.RData$", full.names = TRUE)



# Load each .RData file
for (file in files) {
  load(file)  
}

MS_ss_H2H_10 <- MS_ss_H2H_10 %>% rename(Category = Cat) %>% mutate(Tournament = "ss",.before = Category) 
WS_ss_H2H_10 <- WS_ss_H2H_10 %>% rename(Category = Cat) %>% mutate(Tournament = "ss",.before = Category) 
MS_gp_H2H_10 <- MS_gp_H2H_10 %>% rename(Category = Cat) %>% mutate(Tournament = "gp",.before = Category) 
WS_gp_H2H_10 <- WS_gp_H2H_10 %>% rename(Category = Cat) %>% mutate(Tournament = "gp",.before = Category) 


final_H2H_10 <- rbind(MS_ss_H2H_10,MS_gp_H2H_10,WS_ss_H2H_10,WS_gp_H2H_10)

final_data_10 <- final_data_10 %>% rename(`2 Set Wins` = `2 Set Match Wins`) %>%
  mutate(`Net Loss PCT` = round(100 - `Net Win PCT`,digits=1), .after = `Net Win PCT`) %>%
  mutate(`First Set Win Match Loss PCT` = round(100 - `First Set Win Match Win PCT`,digits=1), .after = `First Set Win Match Win PCT`) %>%
  mutate(`First Set Loss Match Loss PCT` = round(100 - `First Set Loss Match Win PCT`,digits=1), .after = `First Set Loss Match Win PCT`) %>%
  mutate(`3-Set Losses` = round(`3-Set Matches` - `3-Set Wins`,digits=1), .after = `3-Set Wins`) %>%
  mutate(`3-Set Loss PCT` = round(100 - `3-Set Win PCT`,digits=1), .after = `3-Set Win PCT`) %>%
  mutate(`2 Set Losses` = round(`2 Set Matches` - `2 Set Wins`,digits=1), .after = `2 Set Wins`) %>%
  mutate(`2 Set Loss PCT` = round(100 - `2 Set Win PCT`,digits=1), .after = `2 Set Win PCT`) %>%
  mutate(`WW PCT` = round(((WW/Matches)*100),digits=1), .after = `WW`) %>%
  mutate(`WLW PCT` = round(((WLW/Matches)*100),digits=1), .after = `WLW`) %>%
  mutate(`LWW PCT` = round(((LWW/Matches)*100),digits=1), .after = `LWW`) %>%
  mutate(`WLL PCT` = round(((WLL/Matches)*100),digits=1), .after = `WLL`) %>%
  mutate(`LWL PCT` = round(((LWL/Matches)*100),digits=1), .after = `LWL`) %>%
  mutate(`LL PCT` = round(((LL/Matches)*100),digits=1), .after = `LL`) 
    

save(final_H2H_10,file="../Cleaned_10/final_H2H_10.RData")
save(final_data_10,file="../Cleaned_10/final_data_10.RData")
