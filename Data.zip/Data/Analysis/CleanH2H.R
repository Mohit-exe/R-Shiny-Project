###MS
library(tidyverse)
library(dplyr)
load("../Stats_final/MS_superseries_MostPointsH2H.RData")
load("../Stats_final/MS_grandprix_MostPointsH2H.RData")

MS_ss_H2H_temp <- `Stats_final/MS_superseries_MostPointsH2H`
MS_gp_H2H_temp <- `Stats_final/MS_grandprix_MostPointsH2H`

# Define the base sequence (1 to 25)
base_sequence <- 1:25
# Define the maximum value for the last sequence
max_value <- 35400
# Calculate the number of blocks
blocks <- seq(0, max_value, by = 50)
# Generate the sequence by adding each multiple of 50 to `base_sequence`
final_sequence <- unlist(lapply(blocks, function(x) x + base_sequence))

MS_ss_H2H <- MS_ss_H2H_temp %>% select(!(Countries)) %>% slice(final_sequence) %>% 
  mutate(Player_Country = (MS_ss_H2H_temp$Countries)[seq(1,35449,2)],Opponent_Country = (MS_ss_H2H_temp$Countries)[seq(2,35450,2)])



# Define the base sequence (1 to 25)
base_sequence <- 1:25
# Define the maximum value for the last sequence
max_value <- 102700
# Calculate the number of blocks
blocks <- seq(0, max_value, by = 50)
# Generate the sequence by adding each multiple of 50 to `base_sequence`
final_sequence <- unlist(lapply(blocks, function(x) x + base_sequence))

MS_gp_H2H <- MS_gp_H2H_temp %>% select(!(Countries)) %>% slice(final_sequence) %>% 
  mutate(Player_Country = (MS_gp_H2H_temp$Countries)[seq(1,102749,2)],Opponent_Country = (MS_gp_H2H_temp$Countries)[seq(2,102750,2)])

save(MS_ss_H2H,file="../Stats_final/MS_superseries_MostPointsH2H.RData")
save(MS_gp_H2H,file="../Stats_final/MS_grandprix_MostPointsH2H.RData")

####Women
load("../Stats_final/WS_superseries_MostPointsH2H.RData")
load("../Stats_final/WS_grandprix_MostPointsH2H.RData")

WS_ss_H2H_temp <- `Stats_final/WS_superseries_MostPointsH2H`
WS_gp_H2H_temp <- `Stats_final/WS_grandprix_MostPointsH2H`

#For superseries
# Define the base sequence (1 to 25)
base_sequence <- 1:25
# Define the maximum value for the last sequence
max_value <- 26950
# Calculate the number of blocks
blocks <- seq(0, max_value, by = 50)
# Generate the sequence by adding each multiple of 50 to `base_sequence`
final_sequence <- unlist(lapply(blocks, function(x) x + base_sequence))

WS_ss_H2H <- WS_ss_H2H_temp %>% select(!(Countries)) %>% slice(final_sequence) %>% 
  mutate(Player_Country = (WS_ss_H2H_temp$Countries)[seq(1,26999,2)],Opponent_Country = (WS_ss_H2H_temp$Countries)[seq(2,27000,2)])



# Define the base sequence (1 to 25)
base_sequence <- 1:25
# Define the maximum value for the last sequence
max_value <- 39450
# Calculate the number of blocks
blocks <- seq(0, max_value, by = 50)
# Generate the sequence by adding each multiple of 50 to `base_sequence`
final_sequence <- unlist(lapply(blocks, function(x) x + base_sequence))

WS_gp_H2H <- WS_gp_H2H_temp %>% select(!(Countries)) %>% slice(final_sequence) %>% 
  mutate(Player_Country = (WS_gp_H2H_temp$Countries)[seq(1,39499,2)],Opponent_Country = (WS_gp_H2H_temp$Countries)[seq(2,39500,2)])

save(WS_ss_H2H,file="../Stats_final/WS_superseries_MostPointsH2H.RData")
save(WS_gp_H2H,file="../Stats_final/WS_grandprix_MostPointsH2H.RData")


#####################
load("../Stats_final/MS_superseries_MostPointsH2H.RData")
load("../Stats_final/MS_grandprix_MostPointsH2H.RData")
load("../Stats_final/WS_superseries_MostPointsH2H.RData")
load("../Stats_final/WS_grandprix_MostPointsH2H.RData")
##MS_ss
MS_ss_H2H_temp <- MS_ss_H2H %>% select(Players=Opponents, Opponents=Players, Cat, Matches, Wins = Losses, Losses = Wins,
                                       `Points For` = `Points Against`, `Points Against` = `Points For`, Difference, Player_Country = Opponent_Country,
                                       Opponent_Country = Player_Country)
MS_ss_H2H <- rbind(MS_ss_H2H,MS_ss_H2H_temp)


##WS_ss
WS_ss_H2H_temp <- WS_ss_H2H %>% select(Players=Opponents, Opponents=Players, Cat, Matches, Wins = Losses, Losses = Wins,
                                       `Points For` = `Points Against`, `Points Against` = `Points For`, Difference, Player_Country = Opponent_Country,
                                       Opponent_Country = Player_Country)
WS_ss_H2H <- rbind(WS_ss_H2H,WS_ss_H2H_temp)


##MS_gp
MS_gp_H2H_temp <- MS_gp_H2H %>% select(Players=Opponents, Opponents=Players, Cat, Matches, Wins = Losses, Losses = Wins,
                                       `Points For` = `Points Against`, `Points Against` = `Points For`, Difference, Player_Country = Opponent_Country,
                                       Opponent_Country = Player_Country)
MS_gp_H2H <- rbind(MS_gp_H2H,MS_gp_H2H_temp)


##MS_gp
WS_gp_H2H_temp <- WS_gp_H2H %>% select(Players=Opponents, Opponents=Players, Cat, Matches, Wins = Losses, Losses = Wins,
                                       `Points For` = `Points Against`, `Points Against` = `Points For`, Difference, Player_Country = Opponent_Country,
                                       Opponent_Country = Player_Country)
WS_gp_H2H <- rbind(WS_gp_H2H,WS_gp_H2H_temp)

save(MS_ss_H2H,file="../Stats_final/MS_superseries_MostPointsH2H.RData")
save(MS_gp_H2H,file="../Stats_final/MS_grandprix_MostPointsH2H.RData")
save(WS_ss_H2H,file="../Stats_final/WS_superseries_MostPointsH2H.RData")
save(WS_gp_H2H,file="../Stats_final/WS_grandprix_MostPointsH2H.RData")


