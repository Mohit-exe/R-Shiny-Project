###MS
library(tidyverse)
library(dplyr)
load("../Stats_final/MS_superseries_finalsmatches.RData")
load("../Stats_final/MS_grandprix_finalsmatches.RData")

MS_ss_fm_temp <- `Stats_final/MS_superseries_finalsmatches`
MS_gp_fm_temp <- `Stats_final/MS_grandprix_finalsmatches`

# Define the base sequence (1 to 25)
base_sequence <- 1:25
# Define the maximum value for the last sequence
max_value <- 850
# Calculate the number of blocks
blocks <- seq(0, max_value, by = 50)
# Generate the sequence by adding each multiple of 50 to `base_sequence`
final_sequence <- unlist(lapply(blocks, function(x) x + base_sequence))

MS_ss_fm <- MS_ss_fm_temp %>% select(!(Countries)) %>% slice(final_sequence) %>% 
  mutate(Player_Country = (MS_ss_fm_temp$Countries)[seq(1,899,2)],Opponent_Country = (MS_ss_fm_temp$Countries)[seq(2,900,2)])



# Define the base sequence (1 to 25)
base_sequence <- 1:25
# Define the maximum value for the last sequence
max_value <- 1000
# Calculate the number of blocks
blocks <- seq(0, max_value, by = 50)
# Generate the sequence by adding each multiple of 50 to `base_sequence`
final_sequence <- unlist(lapply(blocks, function(x) x + base_sequence))

MS_gp_fm <- MS_gp_fm_temp %>% select(!(Countries)) %>% slice(final_sequence) %>% 
  mutate(Player_Country = (MS_gp_fm_temp$Countries)[seq(1,1049,2)],Opponent_Country = (MS_gp_fm_temp$Countries)[seq(2,1050,2)])

save(MS_ss_fm,file="../Stats_final/MS_superseries_finalsmatches.RData")
save(MS_gp_fm,file="../Stats_final/MS_grandprix_finalsmatches.RData")

####Women
load("../Stats_final/WS_superseries_finalsmatches.RData")
load("../Stats_final/WS_grandprix_finalsmatches.RData")

WS_ss_fm_temp <- `Stats_final/WS_superseries_finalsmatches`
WS_gp_fm_temp <- `Stats_final/WS_grandprix_finalsmatches`

#For superseries
# Define the base sequence (1 to 25)
base_sequence <- 1:25
# Define the maximum value for the last sequence
max_value <- 850
# Calculate the number of blocks
blocks <- seq(0, max_value, by = 50)
# Generate the sequence by adding each multiple of 50 to `base_sequence`
final_sequence <- unlist(lapply(blocks, function(x) x + base_sequence))

WS_ss_fm <- WS_ss_fm_temp %>% select(!(Countries)) %>% slice(final_sequence) %>% 
  mutate(Player_Country = (WS_ss_fm_temp$Countries)[seq(1,899,2)],Opponent_Country = (WS_ss_fm_temp$Countries)[seq(2,900,2)])



# Define the base sequence (1 to 25)
base_sequence <- 1:25
# Define the maximum value for the last sequence
max_value <- 1000
# Calculate the number of blocks
blocks <- seq(0, max_value, by = 50)
# Generate the sequence by adding each multiple of 50 to `base_sequence`
final_sequence <- unlist(lapply(blocks, function(x) x + base_sequence))

WS_gp_fm <- WS_gp_fm_temp %>% select(!(Countries)) %>% slice(final_sequence) %>% 
  mutate(Player_Country = (WS_gp_fm_temp$Countries)[seq(1,1049,2)],Opponent_Country = (WS_gp_fm_temp$Countries)[seq(2,1050,2)])

save(WS_ss_fm,file="../Stats_final/WS_superseries_finalsmatches.RData")
save(WS_gp_fm,file="../Stats_final/WS_grandprix_finalsmatches.RData")

##################
load("../Stats_final/MS_superseries_finalsmatches.RData")
load("../Stats_final/MS_grandprix_finalsmatches.RData")
load("../Stats_final/WS_superseries_finalsmatches.RData")
load("../Stats_final/WS_grandprix_finalsmatches.RData")

f <- function(score_string) {
  # Split the score string at commas
  score_pairs <- strsplit(score_string, ",")[[1]]
  # Split each score pair at '-'
  tuples <- lapply(score_pairs, function(x) {
    score_values <- as.numeric(unlist(strsplit(x, "-")))
    return(c(score_values[2],score_values[1]))  # Return numeric vector
  })
  return(tuples)  # Return list of numeric vectors
}

f_org <- function(score_string) {
  # Split the score string at commas
  score_pairs <- strsplit(score_string, ",")[[1]]
  # Split each score pair at '-'
  tuples <- lapply(score_pairs, function(x) {
    score_values <- as.numeric(unlist(strsplit(x, "-")))
    return(score_values)  # Return numeric vector
  })
  return(tuples)  # Return list of numeric vectors
}








##MS_ss
MS_ss_fm_temp <- MS_ss_fm %>% select(Players=Opponents, Opponents=Players, Tournament, Date, Category, Score, Player_Country = Opponent_Country,
                                     Opponent_Country = Player_Country) %>% mutate(Score = lapply(Score,f))
MS_ss_fm <- MS_ss_fm  %>% mutate(Score = lapply(Score,f_org))
MS_ss_fm <- rbind(MS_ss_fm,MS_ss_fm_temp)


##WS_ss
WS_ss_fm_temp <- WS_ss_fm %>% select(Players=Opponents, Opponents=Players, Tournament, Date, Category, Score, Player_Country = Opponent_Country,
                                     Opponent_Country = Player_Country) %>% mutate(Score = lapply(Score,f))
WS_ss_fm <- WS_ss_fm  %>% mutate(Score = lapply(Score,f_org))
WS_ss_fm <- rbind(WS_ss_fm,WS_ss_fm_temp)


##MS_gp
MS_gp_fm_temp <- MS_gp_fm %>% select(Players=Opponents, Opponents=Players, Tournament, Date, Category, Score, Player_Country = Opponent_Country,
                                     Opponent_Country = Player_Country) %>% mutate(Score = lapply(Score,f))
MS_gp_fm <- MS_gp_fm  %>% mutate(Score = lapply(Score,f_org))
MS_gp_fm <- rbind(MS_gp_fm,MS_gp_fm_temp)


##MS_gp
WS_gp_fm_temp <- WS_gp_fm %>% select(Players=Opponents, Opponents=Players, Tournament, Date, Category, Score, Player_Country = Opponent_Country,
                                       Opponent_Country = Player_Country) %>% mutate(Score = lapply(Score,f))
WS_gp_fm <- WS_gp_fm  %>% mutate(Score = lapply(Score,f_org))
WS_gp_fm <- rbind(WS_gp_fm,WS_gp_fm_temp)

save(MS_ss_fm,file="../Stats_final/MS_superseries_finalsmatches.RData")
save(MS_gp_fm,file="../Stats_final/MS_grandprix_finalsmatches.RData")
save(WS_ss_fm,file="../Stats_final/WS_superseries_finalsmatches.RData")
save(WS_gp_fm,file="../Stats_final/WS_grandprix_finalsmatches.RData")

