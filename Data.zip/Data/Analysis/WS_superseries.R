library(tidyverse)
library(dplyr)

# Set the directory path
data_dir <- "../Stats_final/"

# List all .RData files in the directory that start with "WS_superseries"
files <- list.files(path = data_dir, pattern = "^WS_superseries.*\\.RData$", full.names = TRUE)



# Load each .RData file
for (file in files) {
  load(file)  
}

#load("../Stats_final/WS_ranking_22.RData")

#load("../Stats_final/WS_ranking_all.RData")###Initial data



WS_ss_T10consweeks <- `Stats_final/WS_superseries_MostConsecutiveWeeksTop10BWFRanking`
WS_ss_WL <- `Stats_final/WS_superseries_PlayerWinsAndLosses`
WS_ss_3set <- `Stats_final/WS_superseries_ThreeSetPercentages`
WS_ss_T10 <- `Stats_final/WS_superseries_WeeksInTop10Ranking`
WS_ss_1setw <- WS_superseries_FirstSetWins#WS_superseries_FirstSetWins
WS_ss_1setl <- WS_superseries_FirstSetLosses



##########Finished
WS_ss_1setw  <- WS_ss_1setw %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% 
  mutate(`Win PCT` = as.numeric(gsub("%", "", `Win PCT`)))
WS_ss_1setl  <- WS_ss_1setl %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% 
  mutate(`Win PCT` = as.numeric(gsub("%", "", `Win PCT`)))                                                  
WS_ss_3set <- WS_ss_3set %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% 
  mutate(`3-Set PCT▼` = as.numeric(gsub("%", "", `3-Set PCT▼`)),`3-Set Win PCT` = as.numeric(gsub("%", "", `3-Set Win PCT`))) %>% rename(`3-Set PCT` = `3-Set PCT▼`)                                                   
WS_ss_WL  <- WS_ss_WL %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% 
  mutate(`Win PCT` = as.numeric(gsub("%", "", `Win PCT`)))                                                  
WS_ss_H2H  <- WS_ss_H2H %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() #%>% slice(16:35450)   
WS_ss_T10 <- WS_ss_T10 %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na()           
WS_ss_T10consweeks <- WS_ss_T10consweeks %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na()
WS_ss_fm  <- WS_ss_fm %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() 
#mens.ranking_all <- mens.ranking_all %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% slice(2:1792)


Players_temp <- WS_ss_3set %>%
  semi_join(WS_ss_WL, by = c("Players", "Countries")) %>%
  semi_join(WS_ss_1setw, by = c("Players", "Countries")) %>%
  semi_join(WS_ss_1setl, by = c("Players", "Countries")) %>%
  semi_join(WS_ss_H2H, by = c("Players", "Countries" = "Player_Country"))



###########
WS_ss_1setw_common <- WS_ss_1setw %>% 
  filter(paste(Players, Countries) %in% paste(Players_temp$Players, Players_temp$Countries)) %>% 
  distinct()

WS_ss_1setl_common <- WS_ss_1setl %>% 
  filter(paste(Players, Countries) %in% paste(Players_temp$Players, Players_temp$Countries)) %>% 
  distinct()

WS_ss_3set_common <- WS_ss_3set %>% 
  filter(paste(Players, Countries) %in% paste(Players_temp$Players, Players_temp$Countries)) %>% 
  distinct()

WS_ss_H2H_common <- WS_ss_H2H %>% 
  filter(paste(Players, Player_Country) %in% paste(Players_temp$Players, Players_temp$Countries)) %>% 
  distinct()

WS_ss_T10_common <- WS_ss_T10 %>% 
  filter(paste(Players, Countries) %in% paste(Players_temp$Players, Players_temp$Countries)) %>% 
  distinct()

WS_ss_T10consweeks_common <- WS_ss_T10consweeks %>% 
  filter(paste(Players, Countries) %in% paste(Players_temp$Players, Players_temp$Countries)) %>% 
  distinct()

WS_ss_fm_common <- WS_ss_fm %>% 
  filter(paste(Players, Player_Country) %in% paste(Players_temp$Players, Players_temp$Countries)) %>% 
  distinct()














#########333

WS_ss_WL_common_temp <- bind_cols(Players = WS_ss_1setw_common$Players,Category = WS_ss_1setw_common$Category,Matches = WS_ss_1setw_common$`First Set Wins`+ WS_ss_1setl_common$`First Set Losses`,
                                  Wins = WS_ss_1setw_common$`Wins▼` + WS_ss_1setl_common$`Wins▼`,Losses = WS_ss_1setw_common$Losses+WS_ss_1setl_common$Losses,
                                  Countries = WS_ss_1setw_common$Countries)
WS_ss_WL_common <- WS_ss_WL_common_temp %>% mutate(`Win PCT` = round((Wins/Matches)*100)) %>% relocate(`Win PCT`,.before =  Countries)

WS_ss_WL_common <- WS_ss_WL_common %>% group_by(Countries) #%>% arrange(desc(`Win PCT`))

WS_ss_1setw_common <- WS_ss_1setw_common %>% 
  mutate(Matches = WS_ss_WL_common$Matches) %>% 
  relocate(Matches, .before = `First Set Wins`) %>% 
  mutate(`First Set Wins PCT` = round((`First Set Wins`/ Matches)*100,digits = 1)) %>% 
  relocate(`First Set Wins PCT`,.before = `Wins▼` )
WS_ss_1setl_common <- WS_ss_1setl_common %>% 
  mutate(Matches = WS_ss_WL_common$Matches) %>% 
  relocate(Matches, .before = `First Set Losses`) %>%
  mutate(`First Set Losses PCT` = round((`First Set Losses`/ Matches)*100,digits = 1)) %>% 
  relocate(`First Set Losses PCT`,.before = `Wins▼` )
WS_ss_fm_common <-  WS_ss_fm_common %>% arrange(Players,Opponents)
################################

WS_ss_WL_common <- WS_ss_WL_common %>%
  rename(
    `Net Wins` = Wins,             # Rename Wins to Net Wins
    `Net Losses` = Losses,
    `Net Win PCT` = `Win PCT`     # Rename Win PCT to Net Win PCT
    # Keep Countries column the same
  )

# Rename columns for WS_ss_1setw_common (First Set Wins)
WS_ss_1setw_common <- WS_ss_1setw_common %>%
  rename(
    
    `First Set Win Match Win` = `Wins▼`,
    `First Set Win Match Loss` = `Losses`,
    `First Set Win Match Win PCT` = `Win PCT`
    # Keep Countries column the same
  )

# Rename columns for WS_ss_1setl_common (First Set Losses)
WS_ss_1setl_common <- WS_ss_1setl_common %>%
  rename(
    
    `First Set Loss Match Win` = `Wins▼`,
    `First Set Loss Match Loss` = `Losses`,
    `First Set Loss Match Win PCT` = `Win PCT`
    # Keep Countries column the same
  )


WS_data_common <- WS_ss_WL_common %>%
  left_join(WS_ss_1setw_common, by = c("Players", "Category", "Matches", "Countries")) %>%
  left_join(WS_ss_1setl_common, by = c("Players", "Category", "Matches", "Countries")) %>%
  left_join(WS_ss_3set_common, by = c("Players", "Category", "Matches", "Countries")) %>% 
  relocate(Countries,.after = Category)


########################
rows_with_na <- apply(WS_data_common, 1, function(row) any(is.na(row)))

Players_ <- WS_data_common[rows_with_na,]$Players
ThreeSetMatch <- WS_ss_3set_common %>% filter(Players %in% Players_) %>% select(`3-Set Matches`:`3-Set Win PCT`)
WS_data_common[WS_data_common$Players %in% Players_,c("3-Set Matches","3-Set PCT","3-Set Wins","3-Set Win PCT")] <- ThreeSetMatch



############
WS_data_common <- WS_data_common %>% 
  mutate(`2 Set Matches` = Matches - `3-Set Matches`,`2 Set Match Wins` = `Net Wins` - `3-Set Wins`) %>% 
  mutate(`2 Set Win PCT` = round((`2 Set Match Wins`/`2 Set Matches`)*100,digits = 1)) %>%
  mutate(`2 Set PCT` = round((`2 Set Matches`/Matches)*100,digits = 1)) %>% 
  relocate(`2 Set PCT`,.after = `2 Set Matches`)



##Cleaning all the minus
WS_data_common[WS_data_common$`3-Set Matches` >= WS_data_common$`Matches` ,"3-Set Matches"] = WS_data_common %>% 
  filter(`3-Set Matches` >= `Matches`) %>%
  mutate(`3-Set Matches` = round((`3-Set PCT`/100)*Matches)) %>%
  pull(`3-Set Matches`)
WS_data_common[WS_data_common$`2 Set Matches` <= 0 ,"3-Set Wins"] = WS_data_common %>% 
  filter(`2 Set Matches` <= 0) %>% 
  mutate(`3-Set Wins` = round((`3-Set Win PCT`/100)*`3-Set Matches`)) %>% 
  pull(`3-Set Wins`)




WS_data_common <- WS_data_common %>% filter(!(`2 Set Match Wins` >= `2 Set Matches`))

##########
WS_data_common <- WS_data_common %>% mutate(WW = `2 Set Match Wins`, WLW = `First Set Win Match Win` - `2 Set Match Wins`,
                                            LWW = `First Set Loss Match Win`, WLL = `First Set Win Match Loss`,
                                            LWL = `First Set Loss Match Loss` - (`2 Set Matches` - `2 Set Match Wins`),
                                            LL = `2 Set Matches` - `2 Set Match Wins`,  ) %>%
  filter_all(all_vars(. >= 0))









##########################
Countries.10 <- WS_data_common %>%
  group_by(Countries) %>%          # Group by 'Countries'
  summarise(n = n()) %>%           # Count the occurrences for each country
  arrange(desc(n)) %>%             # Sort by the count in descending order
  slice(1:10) %>%                  # Select the top 10 countries
  pull(Countries)  

Players.10 <- WS_data_common %>%
  filter(Countries %in% Countries.10) %>%
  group_by(Countries) %>%
  arrange(desc(`Matches`)) %>%   # Arrange within each country by "Net Win PCT" in descending order
  slice_head(n = 10) %>%              # Select the top 10 players for each country
  pull(Players)

rm(Players_temp)




##############
WS_ss_1setw_10 <- WS_ss_1setw_common %>% filter(Players %in% Players.10)
WS_ss_1setl_10  <- WS_ss_1setl_common %>% filter(Players %in% Players.10)                                              
WS_ss_3set_10 <- WS_ss_3set_common %>% filter(Players %in% Players.10) 
WS_ss_H2H_10  <- WS_ss_H2H_common %>% filter(Players %in% Players.10) 
WS_ss_T10_10 <- WS_ss_T10_common %>% filter(Players %in% Players.10) 
WS_ss_T10consweeks_10 <- WS_ss_T10consweeks_common %>% filter(Players %in% Players.10) 
WS_ss_fm_10  <- WS_ss_fm_common %>% filter(Players %in% Players.10)
WS_ss_WL_10 <- WS_ss_WL_common %>% filter(Players %in% Players.10) %>% arrange(Players)



WS_data_10 <- WS_data_common %>% filter(Players %in% Players.10) %>% arrange(Players)
################


WS_ss_data_10 <- WS_data_10
WS_ss_data_common <- WS_data_common

save(WS_ss_data_10,file="../Cleaned_10/WS_ss_data_10.RData")
save(WS_ss_data_common,file="../Cleaned_10/WS_ss_data_common.RData")


save(WS_ss_T10consweeks,file="../Stats_final/WS_superseries_MostConsecutiveWeeksTop10BWFRanking.RData")
save(WS_ss_WL,file="../Stats_final/WS_superseries_PlayerWinsAndLosses.RData")
save(WS_ss_3set,file="../Stats_final/WS_superseries_ThreeSetPercentages.RData")
save(WS_ss_T10,file="../Stats_final/WS_superseries_WeeksInTop10Ranking.RData")
save(WS_ss_1setw,file="../Stats_final/WS_superseries_FirstSetWins.RData")
save(WS_ss_1setl,file="../Stats_final/WS_superseries_FirstSetLosses.RData")
save(WS_ss_fm,file="../Stats_final/WS_superseries_finalsmatches.RData")
#save(mens.ranking_all, file="../Stats_final/WS_ranking_all.RData")



save(WS_ss_1setw_10,file="../Cleaned_10/WS_ss_1setw_10.RData")
save(WS_ss_1setl_10,file="../Cleaned_10/WS_ss_1setl_10.RData")
save(WS_ss_3set_10,file="../Cleaned_10/WS_ss_3set_10.RData")
save(WS_ss_H2H_10,file="../Cleaned_10/WS_ss_H2H_10.RData")
save(WS_ss_WL_10,file="../Cleaned_10/WS_ss_WL_10.RData")
save(WS_ss_fm_10,file="../Cleaned_10/WS_ss_fm_10.RData")
save(WS_ss_T10_10,file="../Cleaned_10/WS_ss_T10_10.RData")
save(WS_ss_T10consweeks_10,file="../Cleaned_10/WS_ss_T10consweeks_10.RData")
#save(mens.ranking_all,file="../Cleaned_10/WS_Ranking_all.RData")
