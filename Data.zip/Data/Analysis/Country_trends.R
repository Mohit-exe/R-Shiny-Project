##################
library(tidyverse)
library(dplyr)
library(ggplot2)
data_dir <- "../Cleaned_10/"

# List all .RData files in the directory that start with "MS_superseries"
files <- list.files(path = data_dir, pattern = "^MS_ss.*\\.RData$", full.names = TRUE)
for (file in files) {
  load(file)  
}


ggplot(MS_ss_1setw_10, aes(x = Countries, y = `First Set Win Match Win PCT`, fill = Countries)) +
  geom_boxplot() +
  labs(title = "Win Percentage after First Set Win ", x = "Country", y = "Win Percentage") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme_minimal()

ggplot(MS_ss_1setl_10, aes(x = Countries, y = `First Set Loss Match Win PCT`, fill = Countries)) +
  geom_boxplot() +
  labs(title = "Win Percentage after First Set Loss", x = "Country", y = "Win Percentage") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme_minimal()

ggplot(MS_ss_3set_10, aes(x = Countries, y = `3-Set Win PCT`, fill = Countries)) +
  geom_boxplot() +
  labs(title = "3 Set Win Percentage", x = "Country", y = "Win Percentage") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme_minimal()

ggplot(MS_ss_3set_10, aes(x = Countries, y = `3-Set PCT`, fill = Countries)) +
  geom_boxplot() +
  labs(title = "3 Set Percentage", x = "Country", y = "Percentage") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme_minimal()

ggplot(MS_ss_WL_10, aes(x = Countries, y = `Net Win PCT`, fill = Countries)) +
  geom_boxplot() +
  labs(title = "Win Percentage", x = "Country", y = "Win Percentage") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme_minimal()





# Density plot for win percentage after first set win
ggplot(MS_ss_1setw_10, aes(x = `First Set Win Match Win PCT`, fill = Countries)) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Distribution of Win Percentage after First Set Win", 
       x = "Win Percentage", y = "Density") +
  theme_minimal()

# Density plot for win percentage after first set loss
ggplot(MS_ss_1setl_10, aes(x = `Win PCT`, fill = Countries)) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Distribution of Win Percentage after First Set Loss", 
       x = "Win Percentage", y = "Density") +
  theme_minimal()

# Density plot for 3-set win percentage
ggplot(MS_ss_3set_10, aes(x = `3-Set Win PCT`, fill = Countries)) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Distribution of 3-Set Win Percentage", 
       x = "3-Set Win Percentage", y = "Density") +
  theme_minimal()

###########################
quartiles_1setw <- MS_ss_1setw_10 %>%
  group_by(Countries) %>%
  summarize(Q1 = quantile(`Win PCT`, 0.25),
            Median = quantile(`Win PCT`, 0.5),
            Q3 = quantile(`Win PCT`, 0.75))

# Density plot with quartile lines for win percentage after first set win
ggplot(MS_ss_1setw_10, aes(x = `Win PCT`, fill = Countries)) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Distribution of Win Percentage after First Set Win", 
       x = "Win Percentage", y = "Density") +
  theme_minimal() +
  geom_vline(data = quartiles_1setw, aes(xintercept = Q1, color = Countries), linetype = "dashed") +
  geom_vline(data = quartiles_1setw, aes(xintercept = Median, color = Countries), linetype = "solid") +
  geom_vline(data = quartiles_1setw, aes(xintercept = Q3, color = Countries), linetype = "dashed")

# Repeat for win percentage after first set loss
quartiles_1setl <- MS_ss_1setl_10 %>%
  group_by(Countries) %>%
  summarize(Q1 = quantile(`Win PCT`, 0.25),
            Median = quantile(`Win PCT`, 0.5),
            Q3 = quantile(`Win PCT`, 0.75))

ggplot(MS_ss_1setl_10, aes(x = `Win PCT`, fill = Countries)) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Distribution of Win Percentage after First Set Loss", 
       x = "Win Percentage", y = "Density") +
  theme_minimal() +
  geom_vline(data = quartiles_1setl, aes(xintercept = Q1, color = Countries), linetype = "dashed") +
  geom_vline(data = quartiles_1setl, aes(xintercept = Median, color = Countries), linetype = "solid") +
  geom_vline(data = quartiles_1setl, aes(xintercept = Q3, color = Countries), linetype = "dashed")

# Repeat for 3-set win percentage
quartiles_3set <- MS_ss_3set_10 %>%
  group_by(Countries) %>%
  summarize(Q1 = quantile(`3-Set Win PCT`, 0.25),
            Median = quantile(`3-Set Win PCT`, 0.5),
            Q3 = quantile(`3-Set Win PCT`, 0.75))

ggplot(MS_ss_3set_10, aes(x = `3-Set Win PCT`, fill = Countries)) +
  geom_density(alpha = 0.6) +
  labs(title = "Density Distribution of 3-Set Win Percentage", 
       x = "3-Set Win Percentage", y = "Density") +
  theme_minimal() +
  geom_vline(data = quartiles_3set, aes(xintercept = Q1, color = Countries), linetype = "dashed") +
  geom_vline(data = quartiles_3set, aes(xintercept = Median, color = Countries), linetype = "solid") +
  geom_vline(data = quartiles_3set, aes(xintercept = Q3, color = Countries), linetype = "dashed")
#######################3




ggplot(MS_ss_1setw_10, aes(x = `First Set Wins PCT`, y = `First Set Win Match Win PCT`, color = Countries)) + 
  geom_point() +
  labs(title = "Comparison of First Set Win Percentage and Overall Win Percentage",
       x = "First Set Win Percentage", 
       y = "Overall Win Percentage") +
  theme_minimal() +
  theme(legend.title = element_blank())  # Optional: Hide legend title
################

MS_data_10 %>%
  summarise(correlation = cor(`First Set Wins PCT`, `Net Win PCT`, use = "complete.obs"))

# Calculate correlation for First Set Wins PCT with First Set Win Match Win PCT
MS_data_10 %>%
  summarise(correlation = cor(`First Set Wins PCT`, `First Set Win Match Win PCT`, use = "complete.obs"))


# Calculate correlation for First Set Losses PCT with First Set Win Match Win PCT
MS_data_10 %>%
  summarise(correlation = cor(`First Set Losses PCT`, `First Set Loss Match Win PCT`, use = "complete.obs"))



# Calculate correlation for First Set Wins PCT with Net Win PCT (without grouping by countries)
MS_data_10 %>%
  ungroup() %>%  # Remove any existing grouping
  summarise(correlation = cor(`First Set Wins PCT`, `Net Win PCT`, use = "complete.obs"))

# Calculate correlation for First Set Wins PCT with First Set Win Match Win PCT (without grouping by countries)
MS_data_10 %>%
  ungroup() %>%  # Remove any existing grouping
  summarise(correlation = cor(`First Set Wins PCT`, `First Set Win Match Win PCT`, use = "complete.obs"))


# Calculate correlation for First Set Losses PCT with First Set Loss Match Win PCT (without grouping by countries)
MS_data_10 %>%
  ungroup() %>%  # Remove any existing grouping
  summarise(correlation = cor(`First Set Losses PCT`, `First Set Loss Match Win PCT`, use = "complete.obs"))





ggplot(MS_data_10, aes(x = Countries, y = `2 Set Win PCT`,fill = Countries) ) +
  geom_boxplot() +
  labs(title = "Boxplot of 2-Set Win Percentage by Country",
       x = "Country",
       y = "2-Set Win Percentage") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))



# Step 1: Extract the relevant columns for the patterns (6 variables)
patterns_data <- MS_data_10 %>% ungroup() %>%
  select(Players, `WW`, `WLW`, `LWW`, `WLL`, `LWL`, `LL`, Matches)

# Step 2: Calculate normalized percentages for the patterns (frequency / Matches * 100)
patterns_data_normalized <- patterns_data %>%
  mutate(
    WW_pct = (`WW` / Matches) * 100,
    WLW_pct = (`WLW` / Matches) * 100,
    LWW_pct = (`LWW` / Matches) * 100,
    WLL_pct = (`WLL` / Matches) * 100,
    LWL_pct = (`LWL` / Matches) * 100,
    LL_pct = (`LL` / Matches) * 100
  ) %>%
  select(Players, WW_pct, WLW_pct, LWW_pct, WLL_pct, LWL_pct, LL_pct)

patterns_data_scaled <- patterns_data_normalized %>%
  mutate(
    WW_pct = WW_pct / max(WW_pct),
    WLW_pct = WLW_pct / max(WLW_pct),
    LWW_pct = LWW_pct / max(LWW_pct),
    WLL_pct = WLL_pct / max(WLL_pct),
    LWL_pct = LWL_pct / max(LWL_pct),
    LL_pct = LL_pct / max(LL_pct)
  )

patterns_data_long <- patterns_data_scaled %>%
  pivot_longer(cols = ends_with("_pct"), names_to = "Pattern", values_to = "Normalized") %>%
  mutate(Pattern = gsub("_pct", "", Pattern))  # Clean up column names


# Step 4: Select the data for a specific player (e.g., Player 5 or any player)
player_5_data <- patterns_data_long %>%
  filter(Players == MS_data_10$Players[3])

# Step 5: Create the radial plot
ggplot(player_5_data, aes(x = Pattern, y = Normalized, fill = Pattern)) +
  geom_bar(stat = "identity") +
  coord_polar() +
  labs(
    title = paste("Normalized and Scaled Match Pattern for Player:", MS_data_10$Players[88]),
    x = "Pattern",
    y = "Normalized Percentage"
  ) +
  theme_minimal() +
  theme(legend.position = "none") +
  scale_fill_manual(values = c("red", "blue", "green", "purple", "orange", "yellow"))


MS_data_10 %>% ungroup() %>% filter(((WW/Matches)*100) == max((WW/Matches)*100))
