### Loading the necessary dependencies
library(rvest)
library(tidyverse)
library(dplyr)

load("../Stats_final/WS_superseries_FirstSetWins.RData")
load("../Stats_final/WS_superseries_FirstSetLosses.RData")

superseries_FirstSetWins <- WS_superseries_FirstSetWins
superseries_FirstSetLosses <- WS_superseries_FirstSetLosses

save(superseries_FirstSetWins,file='../Stats_final/superseries_FirstSetWins.RData')
save(superseries_FirstSetLosses,file='../Stats_final/superseries_FirstSetLosses.RData')



WS_superseries_FirstSetWins <- superseries_FirstSetWins %>% filter(Category=='WS')
MS_superseries_FirstSetWins <- superseries_FirstSetWins %>% filter(Category=='MS')
WS_superseries_FirstSetLosses <- superseries_FirstSetLosses %>% filter(Category=='WS')
MS_superseries_FirstSetLosses <-superseries_FirstSetLosses %>% filter(Category=='MS')

save(WS_superseries_FirstSetWins,file='../Stats_final/Stats/WS_superseries_FirstSetWins.RData')
save(MS_superseries_FirstSetWins,file='../Stats_final/Stats/MS_superseries_FirstSetWins.RData')
save(WS_superseries_FirstSetLosses,file='../Stats_final/Stats/WS_superseries_FirstSetLosses.RData')
save(MS_superseries_FirstSetLosses,file='../Stats_final/Stats/MS_superseries_FirstSetLosses.RData')






load("../Stats_final/WS_grandprix_FirstSetWins.RData")
load("../Stats_final/WS_grandprix_FirstSetLosses.RData")

grandprix_FirstSetWins <- WS_grandprix_FirstSetWins
grandprix_FirstSetLosses <- WS_grandprix_FirstSetLosses

save(grandprix_FirstSetWins,file='grandprix_FirstSetWins.RData')
save(grandprix_FirstSetLosses,file='grandprix_FirstSetLosses.RData')



WS_grandprix_FirstSetWins <-grandprix_FirstSetWins %>% filter(Category=='WS')
MS_grandprix_FirstSetWins <- grandprix_FirstSetWins %>% filter(Category=='MS')
WS_grandprix_FirstSetLosses <- grandprix_FirstSetLosses %>% filter(Category=='WS')
MS_grandprix_FirstSetLosses <-grandprix_FirstSetLosses %>% filter(Category=='MS')

save(WS_grandprix_FirstSetWins,file='../Stats_final/Stats/WS_grandprix_FirstSetWins.RData')
save(MS_grandprix_FirstSetWins,file='../Stats_final/Stats/MS_grandprix_FirstSetWins.RData')
save(WS_grandprix_FirstSetLosses,file='../Stats_final/Stats/WS_grandprix_FirstSetLosses.RData')
save(MS_grandprix_FirstSetLosses,file='../Stats_final/Stats/MS_grandprix_FirstSetLosses.RData')












