library(tidyverse)
library(dplyr)

# Set the directory path
data_dir <- "../Stats_final/"

# List all .RData files in the directory that start with "MS_superseries"
files <- list.files(path = data_dir, pattern = "^MS_superseries.*\\.RData$", full.names = TRUE)



# Load each .RData file
for (file in files) {
  load(file)  
}

load("../Stats_final/MS_ranking_22.RData")

load("../Stats_final/MS_ranking_all.RData")###Initial data



MS_ss_T10consweeks <- `Stats_final/MS_superseries_MostConsecutiveWeeksTop10BWFRanking`
MS_ss_WL <- `Stats_final/MS_superseries_PlayerWinsAndLosses`
MS_ss_3set <- `Stats_final/MS_superseries_ThreeSetPercentages`
MS_ss_T10 <- `Stats_final/MS_superseries_WeeksInTop10Ranking`
MS_ss_1setw <- MS_ss_1setl#MS_superseries_FirstSetWins
MS_ss_1setl <- MS_superseries_FirstSetLosses



##########Finished
MS_ss_1setw  <- MS_ss_1setw %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% 
  mutate(`Win PCT` = as.numeric(gsub("%", "", `Win PCT`)))
MS_ss_1setl  <- MS_ss_1setl %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% 
  mutate(`Win PCT` = as.numeric(gsub("%", "", `Win PCT`)))                                                  
MS_ss_3set <- MS_ss_3set %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% 
  mutate(`3-Set PCT▼` = as.numeric(gsub("%", "", `3-Set PCT▼`)),`3-Set Win PCT` = as.numeric(gsub("%", "", `3-Set Win PCT`))) %>% rename(`3-Set PCT` = `3-Set PCT▼`)                                                   
MS_ss_WL  <- MS_ss_WL %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% 
  mutate(`Win PCT` = as.numeric(gsub("%", "", `Win PCT`)))                                                  
MS_ss_H2H  <- MS_ss_H2H %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% slice(16:35450)   
MS_ss_T10 <- MS_ss_T10 %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na()           
MS_ss_T10consweeks <- MS_ss_T10consweeks %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na()
MS_ss_fm  <- MS_ss_fm %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() 
mens.ranking_all <- mens.ranking_all %>% arrange(Players) %>% mutate(Players = toupper(Players)) %>% mutate(across(where(is.character), ~ na_if(., ""))) %>% drop_na() %>% slice(2:1792)


  




Players_temp <- MS_ss_3set %>% 
  filter(Players %in% MS_ss_WL$Players) %>% 
  filter(Players %in% MS_ss_1setw$Players) %>% 
  filter(Players %in% MS_ss_1setl$Players)  %>% 
  filter(Players %in% MS_ss_H2H$Players)
  # Select the top 10 countries
   

MS_ss_1setw_common <- MS_ss_1setw %>% filter(Players %in% (Players_temp %>% pull(Players))) %>% distinct()
MS_ss_1setl_common  <- MS_ss_1setl %>% filter(Players %in% (Players_temp %>% pull(Players))) %>% distinct()                                              
MS_ss_3set_common <- MS_ss_3set %>% filter(Players %in% (Players_temp %>% pull(Players))) %>% distinct()
MS_ss_H2H_common  <- MS_ss_H2H %>% filter(Players %in% (Players_temp %>% pull(Players))) %>% distinct()
MS_ss_T10_common <- MS_ss_T10 %>% filter(Players %in% (Players_temp %>% pull(Players))) %>% distinct()
MS_ss_T10consweeks_common <- MS_ss_T10consweeks %>% filter(Players %in% (Players_temp %>% pull(Players))) 
MS_ss_fm_common  <- MS_ss_fm %>% filter(Players %in% (Players_temp %>% pull(Players)))


MS_ss_WL_common_temp <- bind_cols(Players = MS_ss_1setw_common$Players,Category = MS_ss_1setw_common$Category,Matches = MS_ss_1setw_common$`First Set Wins`+ MS_ss_1setl_common$`First Set Losses`,
                              Wins = MS_ss_1setw_common$`Wins▼` + MS_ss_1setl_common$`Wins▼`,Losses = MS_ss_1setw_common$Losses+MS_ss_1setl_common$Losses,
                              Countries = MS_ss_1setw_common$Countries)
MS_ss_WL_common <- MS_ss_WL_common_temp %>% mutate(`Win PCT` = round((Wins/Matches)*100)) %>% relocate(`Win PCT`,.before =  Countries)

MS_ss_WL_common <- MS_ss_WL_common %>% group_by(Countries) #%>% arrange(desc(`Win PCT`))

MS_ss_1setw_common <- MS_ss_1setw_common %>% 
  mutate(Matches = MS_ss_WL_common$Matches) %>% 
  relocate(Matches, .before = `First Set Wins`) %>% 
  mutate(`First Set Wins PCT` = round((`First Set Wins`/ Matches)*100,digits = 1)) %>% 
  relocate(`First Set Wins PCT`,.before = `Wins▼` )
MS_ss_1setl_common <- MS_ss_1setl_common %>% 
  mutate(Matches = MS_ss_WL_common$Matches) %>% 
  relocate(Matches, .before = `First Set Losses`) %>%
  mutate(`First Set Losses PCT` = round((`First Set Losses`/ Matches)*100,digits = 1)) %>% 
  relocate(`First Set Losses PCT`,.before = `Wins▼` )
MS_ss_fm_common <-  MS_ss_fm_common %>% arrange(Players,Opponents)
################################

MS_ss_WL_common <- MS_ss_WL_common %>%
  rename(
    `Net Wins` = Wins,             # Rename Wins to Net Wins
    `Net Losses` = Losses,
    `Net Win PCT` = `Win PCT`     # Rename Win PCT to Net Win PCT
    # Keep Countries column the same
  )

# Rename columns for MS_ss_1setw_common (First Set Wins)
MS_ss_1setw_common <- MS_ss_1setw_common %>%
  rename(
    
    `First Set Win Match Win` = `Wins▼`,
    `First Set Win Match Loss` = `Losses`,
    `First Set Win Match Win PCT` = `Win PCT`
    # Keep Countries column the same
  )

# Rename columns for MS_ss_1setl_common (First Set Losses)
MS_ss_1setl_common <- MS_ss_1setl_common %>%
  rename(
    
    `First Set Loss Match Win` = `Wins▼`,
    `First Set Loss Match Loss` = `Losses`,
    `First Set Loss Match Win PCT` = `Win PCT`
    # Keep Countries column the same
  )


MS_data_common <- MS_ss_WL_common %>%
  left_join(MS_ss_1setw_common, by = c("Players", "Category", "Matches", "Countries")) %>%
  left_join(MS_ss_1setl_common, by = c("Players", "Category", "Matches", "Countries")) %>%
  left_join(MS_ss_3set_common, by = c("Players", "Category", "Matches", "Countries")) %>% 
  relocate(Countries,.after = Category)


########################
rows_with_na <- apply(MS_data_common, 1, function(row) any(is.na(row)))

Players_ <- MS_data_common[rows_with_na,]$Players
ThreeSetMatch <- MS_ss_3set_common %>% filter(Players %in% Players_) %>% select(`3-Set Matches`:`3-Set Win PCT`)
MS_data_common[MS_data_common$Players %in% Players_,c("3-Set Matches","3-Set PCT","3-Set Wins","3-Set Win PCT")] <- ThreeSetMatch



############
MS_data_common <- MS_data_common %>% 
  mutate(`2 Set Matches` = Matches - `3-Set Matches`,`2 Set Match Wins` = `Net Wins` - `3-Set Wins`) %>% 
  mutate(`2 Set Win PCT` = round((`2 Set Match Wins`/`2 Set Matches`)*100,digits = 1)) %>%
  mutate(`2 Set PCT` = round((`2 Set Matches`/Matches)*100,digits = 1)) %>% 
  relocate(`2 Set PCT`,.after = `2 Set Matches`)



##Cleaning all the minus
MS_data_common[MS_data_common$`3-Set Matches` >= MS_data_common$`Matches` ,"3-Set Matches"] = MS_data_common %>% 
  filter(`3-Set Matches` >= `Matches`) %>%
  mutate(`3-Set Matches` = round((`3-Set PCT`/100)*Matches)) %>%
  pull(`3-Set Matches`)
MS_data_common[MS_data_common$`2 Set Matches` <= 0 ,"3-Set Wins"] = MS_data_common %>% 
  filter(`2 Set Matches` <= 0) %>% 
  mutate(`3-Set Wins` = round((`3-Set Win PCT`/100)*`3-Set Matches`)) %>% 
  pull(`3-Set Wins`)




MS_data_common <- MS_data_common %>% filter(!(`2 Set Match Wins` >= `2 Set Matches`))

##########
MS_data_common <- MS_data_common %>% mutate(WW = `2 Set Match Wins`, WLW = `First Set Win Match Win` - `2 Set Match Wins`,
                              LWW = `First Set Loss Match Win`, WLL = `First Set Win Match Loss`,
                              LWL = `First Set Loss Match Loss` - (`2 Set Matches` - `2 Set Match Wins`),
                              LL = `2 Set Matches` - `2 Set Match Wins`,  ) %>%
                              filter_all(all_vars(. >= 0))





 



##########################
Countries.10 <- MS_data_common %>%
  group_by(Countries) %>%          # Group by 'Countries'
  summarise(n = n()) %>%           # Count the occurrences for each country
  arrange(desc(n)) %>%             # Sort by the count in descending order
  slice(1:10) %>%                  # Select the top 10 countries
  pull(Countries)  

Players.10 <- MS_data_common %>%
  filter(Countries %in% Countries.10) %>%
  group_by(Countries) %>%
  arrange(desc(`Matches`)) %>%   # Arrange within each country by "Net Win PCT" in descending order
  slice_head(n = 10) %>%              # Select the top 10 players for each country
  pull(Players)

rm(Players_temp)




##############
MS_ss_1setw_10 <- MS_ss_1setw_common %>% filter(Players %in% Players.10)
MS_ss_1setl_10  <- MS_ss_1setl_common %>% filter(Players %in% Players.10)                                              
MS_ss_3set_10 <- MS_ss_3set_common %>% filter(Players %in% Players.10) 
MS_ss_H2H_10  <- MS_ss_H2H_common %>% filter(Players %in% Players.10) 
MS_ss_T10_10 <- MS_ss_T10_common %>% filter(Players %in% Players.10) 
MS_ss_T10consweeks_10 <- MS_ss_T10consweeks_common %>% filter(Players %in% Players.10) 
MS_ss_fm_10  <- MS_ss_fm_common %>% filter(Players %in% Players.10)
MS_ss_WL_10 <- MS_ss_WL_common %>% filter(Players %in% Players.10) %>% arrange(Players)



MS_data_10 <- MS_data_common %>% filter(Players %in% Players.10) %>% arrange(Players)
################


MS_ss_data_10 <- MS_data_10
MS_ss_data_common <- MS_data_common

save(MS_ss_data_10,file="../Cleaned_10/MS_ss_data_10.RData")
save(MS_ss_data_common,file="../Cleaned_10/MS_ss_data_common.RData")


save(MS_ss_T10consweeks,file="../Stats_final/MS_superseries_MostConsecutiveWeeksTop10BWFRanking.RData")
save(MS_ss_WL,file="../Stats_final/MS_superseries_PlayerWinsAndLosses.RData")
save(MS_ss_3set,file="../Stats_final/MS_superseries_ThreeSetPercentages.RData")
save(MS_ss_T10,file="../Stats_final/MS_superseries_WeeksInTop10Ranking.RData")
save(MS_ss_1setw,file="../Stats_final/MS_superseries_FirstSetWins.RData")
save(MS_ss_1setl,file="../Stats_final/MS_superseries_FirstSetLosses.RData")
save(MS_ss_fm,file="../Stats_final/MS_superseries_finalsmatches.RData")
save(mens.ranking_all, file="../Stats_final/MS_ranking_all.RData")



save(MS_ss_1setw_10,file="../Cleaned_10/MS_ss_1setw_10.RData")
save(MS_ss_1setl_10,file="../Cleaned_10/MS_ss_1setl_10.RData")
save(MS_ss_3set_10,file="../Cleaned_10/MS_ss_3set_10.RData")
save(MS_ss_H2H_10,file="../Cleaned_10/MS_ss_H2H_10.RData")
save(MS_ss_WL_10,file="../Cleaned_10/MS_ss_WL_10.RData")
save(MS_ss_fm_10,file="../Cleaned_10/MS_ss_fm_10.RData")
save(MS_ss_T10_10,file="../Cleaned_10/MS_ss_T10_10.RData")
save(MS_ss_T10consweeks_10,file="../Cleaned_10/MS_ss_T10consweeks_10.RData")
save(mens.ranking_all,file="../Cleaned_10/MS_Ranking_all.RData")
