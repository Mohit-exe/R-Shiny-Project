# Shiny App

### App usage information

1. **Setup**: Ensure all necessary packages are installed. The script to run the app requires various R packages (e.g., `rvest`, `ggplot`, `dplyr`) for web scraping, data manipulation, and preprocessing the data.

   ```r
   install.packages(c("tidyverse", "tidyr", "rvest", "dplyr", "shiny", "shinydashboard", "DT", "ggplot2", "dashboardthemes", "gridExtra", "stringr", "plotly"))
   ```
