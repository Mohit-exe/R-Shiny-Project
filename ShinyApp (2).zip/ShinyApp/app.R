# Load necessary libraries
library(shiny)
library(tidyr)
library(shinydashboard)
library(DT)
library(ggplot2)
library(dplyr)
library(dashboardthemes)
library(gridExtra)
library(stringr)
library(plotly)

# Load the data
data <- read.csv("final_table.csv")
load("final_data_10.RData")
load("final_H2H_10.RData")
data$Country <- sapply(strsplit(as.character(data$Country), "\\\\"), `[`, 1)


# Define UI
# Define UI
ui <- dashboardPage(
  dashboardHeader(title = "PLAYER ANALYSIS"),
  dashboardSidebar(
    sidebarMenu(id = 'sidebarmenu',
                menuItem('Welcome Page', tabName = 'welcome', icon = icon('tv')),
                menuItem('Rankings', tabName = 'rankings', icon = icon('chart-bar')),
                menuItem('Correlation Analysis', tabName = 'correlation', icon = icon('line-chart')),
                menuItem('Country-Category Analysis', tabName = 'country_category', icon = icon('globe')),
                menuItem('Statistics', tabName = 'statistics', icon = icon('chart-line'),
                         menuSubItem('Data', tabName = 'data', icon = icon('table')),
                         menuSubItem('Country Statistics', tabName = 'countryStats', icon = icon('globe')),
                         menuSubItem('Individual Statistics', tabName = 'individualStats', icon = icon('user'))
                )
    )
  ),
  dashboardBody(
    dashboardthemes::shinyDashboardThemes(theme = "blue_gradient"),
    tabItems(
      # Welcome Page Tab
      tabItem(tabName = 'welcome',
              h1("Welcome to the Analysis Dashboard", align = 'center'),
              img(src = 'Badminton1.jpg', height = "80%", width = "80%", 
                  style = "display: block; margin-left: auto; margin-right: auto;")
      ),
      
      #############################################################
      
      tabItem(tabName = 'rankings',
              h3("Player Analysis Dashboard", align = "center"),
              sidebarLayout(
                sidebarPanel(
                  selectInput("category", "Select Category:", 
                              choices = unique(data$Category), 
                              selected = unique(data$Category)[1],
                              multiple = TRUE),
                  selectInput("country", "Select Country:", 
                              choices = unique(data$Country), 
                              selected = unique(data$Country)[1],
                              multiple = TRUE)
                ),
                mainPanel(
                  tabsetPanel(
                    tabPanel("Data Table", DTOutput("dataTable")),
                    tabPanel("Overview", 
                             plotOutput("rankDistPlot"), 
                             plotOutput("pointsDistPlot")),
                    tabPanel("Top Performers", 
                             plotOutput("topPerformersPlot")),
                    tabPanel("Country Representation", 
                             plotOutput("countryPlot"))
                  )
                )
              )
      ),
      
      # Correlation Analysis Tab with Statistics Table
      tabItem(tabName = 'correlation',
              sidebarLayout(
                sidebarPanel(
                  selectInput("corr_categories", "Select Categories:", 
                              choices = unique(data$Category), 
                              selected = unique(data$Category)[1],
                              multiple = TRUE)
                ),
                mainPanel(
                  tabsetPanel(
                    tabPanel("Correlation Plot", plotOutput("correlationPlot")),
                    tabPanel("Correlation Statistics", DTOutput("correlationStats"))
                  )
                )
              )
      ),
      
      # Country-Category Analysis Tab
      tabItem(tabName = 'country_category',
              sidebarLayout(
                sidebarPanel(
                  selectInput("selected_country", "Select Country:", 
                              choices = unique(data$Country), 
                              selected = unique(data$Country)[1])
                ),
                mainPanel(
                  tabsetPanel(
                    tabPanel("Boxplot & Summary Stats",
                             plotOutput("categoryBoxplot"),
                             tableOutput("summaryStats")),
                    tabPanel("Country Category Average",
                             plotOutput("countryCategoryPlot"))
                  )
                )
              )
      ),
      
      
      
      
      
      
      
      
      
      ################################################################
      
      
      tabItem(tabName = "data",
              h3("PLAYER STATISTICS", align = "center"),
              sidebarLayout(
                sidebarPanel(
                  width = 3,  # Reduce the width of the sidebar itself (ranges from 1 to 12, based on Bootstrap grid system)
                  selectInput("statisticsDataTournament", "Tournament:", 
                              choices = c("Superseries" = "ss", "Grandprix" = "gp"),
                              width = '100%'),  # Dropdown takes up 100% of the sidebar width
                  selectInput("statisticsDataCategory", "Category:", 
                              choices = c("Mens Singles" = "MS", "Womens Singles" = "WS"),
                              width = '100%'),  # Dropdown takes up 100% of the sidebar width
                  selectInput("statisticsDataMetric", "Metric", 
                              choices = c("Frequency" = "freq", "Percentages" = "PCT"),
                              width = '100%')  # Dropdown takes up 100% of the sidebar width
                ),
                mainPanel(
                  width = 9,
                  DTOutput("statisticsDataTable")
                )
              )
      ),
      
      
      tabItem(tabName = "countryStats",
              h3("PERFORMANCE TRENDS AMONG COUNTRIES", align = "center"),
              sidebarLayout(
                sidebarPanel(
                  width = 3,  # Adjust sidebar width as needed
                  selectInput("countryStatsTournament", "Tournament:", 
                              choices = c("Superseries" = "ss", "Grandprix" = "gp"),
                              width = '100%'),
                  selectInput("countryStatsCategory", "Category:", 
                              choices = c("Mens Singles" = "MS", "Womens Singles" = "WS"),
                              width = '100%'),
                  selectInput("countryStatsCountries", "Countries:", 
                              choices = NULL,  # Initially empty, will be populated dynamically
                              multiple = TRUE, 
                              width = '100%'),
                  selectInput("countryStatsMetricType", "Metric Type:", 
                              choices = c("Frequency" = "freq", "Percentages" = "PCT"),
                              width = '100%'),
                  selectInput("countryStatsComparison", "Comparison Parameters:", 
                              choices = NULL,  # Initially empty, will be populated dynamically
                              multiple = TRUE,
                              selectize = TRUE,  # Allow multiple selection
                              width = '100%')
                ),
                mainPanel(
                  width = 9,
                  plotOutput("countryStatsPlot",height = "90vh",width = "100%")  # Output for the plot based on selection
                )
              )
      ),
      
      
      
      tabItem(
        tabName = "individualStats",
        h3("PERFOMANCE TRENDS AMONG PLAYERS", align = "center"),
        
        sidebarLayout(
          sidebarPanel(
            width = 2,  # Adjust sidebar width as needed
            
            # Tournament Selection (Only 'Superseries' and 'Grandprix' options)
            selectInput("individualStatsTournament", "Tournament:", 
                        choices = c("Superseries" = "ss", "Grandprix" = "gp"),
                        width = '100%'),
            
            # Category Selection (No "All" option)
            selectInput("individualStatsCategory", "Category:", 
                        choices = c("Mens Singles" = "MS", "Womens Singles" = "WS"),
                        width = '100%'),
            
            # Country Selection (Default "All")
            selectInput("individualStatsCountry", "Country:", 
                        choices = NULL,  # Country will be populated dynamically
                        #selected = "All",  # Default selection is "All"
                        width = '100%'),
            
            # Player Selection (Will be updated dynamically)
            selectInput("individualStatsPlayer", "Player:", 
                        choices = NULL,  # Players will be populated dynamically based on country
                        width = '100%')
          ),
          
          mainPanel(
            width = 8,
            
            # Tabs for Set Performances and Head-to-Head Performances
            tabsetPanel(
              id = "individualStatsTabs",
              
              tabPanel("Set Performances",
                       # fluidPage(
                       #   plotOutput("setPerformancePlot", height = "600px", width = "600px")
                       # )
                       
                       fluidRow(
                         column(12, 
                                style = "display: flex; justify-content: center;", 
                                plotOutput("setPerformancePlot", height = "500px", width = "100%"))
                       ),
                       
                       
                       br(),
                       
                       # Data table for the selected player with filtered data
                       dataTableOutput("setPerformanceDataTable")
              ),
              
              
              tabPanel("Head-to-Head Performances",
                       # Head-to-Head scatter plot
                       plotlyOutput("headToHeadPlot", height = "500px", width = "100%"),
                       
                       br(),
                       
                       # Data table for selected player
                       dataTableOutput("playerDataTable")
                       
              )
            )
          )
        )
      )
      
      
      
    )
  )
)


# Define server logic
server <- function(input, output,session) {
  #############Rankings section
  # Filtered data based on user selection
  # Filtered data based on user selection
  filtered_data <- reactive({
    data %>% filter(Category %in% input$category, Country %in% input$country)
  })
  
  # Data Table
  output$dataTable <- renderDT({
    datatable(filtered_data(), options = list(pageLength = 10, autoWidth = TRUE), filter = 'top')
  })
  
  # Plot: Ranking Distribution
  output$rankDistPlot <- renderPlot({
    ggplot(filtered_data(), aes(x = Rk)) +
      geom_histogram(bins = 30, fill = "blue", color = "white") +
      labs(title = "Distribution of Rankings", x = "Rank", y = "Count") +
      theme_minimal()
  })
  
  # Plot: Points Distribution
  output$pointsDistPlot <- renderPlot({
    ggplot(filtered_data(), aes(x = Points)) +
      geom_histogram(bins = 30, fill = "green", color = "white") +
      labs(title = "Distribution of Points", x = "Points", y = "Count") +
      theme_minimal()
  })
  
  # Plot: Top Performers
  output$topPerformersPlot <- renderPlot({
    top_performers <- filtered_data() %>%
      arrange(desc(Points)) %>% 
      head(10)
    
    ggplot(top_performers, aes(x = reorder(Players, -Points), y = Points, fill = Country)) +
      geom_bar(stat = "identity") +
      coord_flip() +
      labs(title = "Top 10 Performers by Points", x = "Player", y = "Points") +
      theme_minimal()
  })
  
  # Correlation Plot
  output$correlationPlot <- renderPlot({
    corr_data <- data %>% filter(Category %in% input$corr_categories)
    
    ggplot(corr_data, aes(x = Rk, y = Points, color = Category)) +
      geom_point(alpha = 0.7) +
      geom_smooth(method = "lm", se = FALSE) +
      labs(title = "Correlation between Ranking and Points", x = "Rank", y = "Points") +
      theme_minimal() +
      scale_color_brewer(palette = "Set1")
  })
  
  # Correlation Statistics Table
  output$correlationStats <- renderDT({
    corr_data <- data %>% filter(Category %in% input$corr_categories)
    correlation_stats <- corr_data %>%
      group_by(Category) %>%
      summarise(Correlation = cor(Rk, Points, use = "complete.obs"))
    
    datatable(correlation_stats, options = list(pageLength = 5, autoWidth = TRUE),
              caption = "Correlation Coefficients between Ranking and Points")
  })
  
  # Plot: Country Representation (Top 10)
  output$countryPlot <- renderPlot({
    country_counts <- filtered_data() %>%
      group_by(Country) %>%
      summarise(count = n()) %>%
      arrange(desc(count)) %>%
      head(10)
    
    ggplot(country_counts, aes(x = reorder(Country, -count), y = count, fill = Country)) +
      geom_bar(stat = "identity") +
      coord_flip() +
      labs(title = "Top 10 Countries by Player Count", x = "Country", y = "Count") +
      theme_minimal()
  })
  
  # Boxplot: Points by Category
  output$categoryBoxplot <- renderPlot({
    country_data <- data %>% filter(Country == input$selected_country)
    
    ggplot(country_data, aes(x = Category, y = Points, fill = Category)) +
      geom_boxplot(outlier.color = "red") +
      labs(title = paste("Boxplot of Points by Category for", input$selected_country), 
           x = "Category", y = "Points") +
      theme_minimal()
  })
  # Summary Statistics Table
  output$summaryStats <- renderTable({
    country_data <- data %>% filter(Country == input$selected_country)
    
    country_data %>%
      group_by(Category) %>%
      summarise(
        Min = min(Points, na.rm = TRUE),
        Max = max(Points, na.rm = TRUE),
        Mean = mean(Points, na.rm = TRUE),
        Median = median(Points, na.rm = TRUE),
        SD = sd(Points, na.rm = TRUE)
      )
  })
  
  # Plot: Country-Category Average Points
  output$countryCategoryPlot <- renderPlot({
    country_data <- data %>% filter(Country == input$selected_country) %>%
      group_by(Category) %>%
      summarise(AveragePoints = mean(Points, na.rm = TRUE))
    
    ggplot(country_data, aes(x = Category, y = AveragePoints, fill = Category)) +
      geom_bar(stat = "identity") +
      labs(title = paste("Average Points by Category for", input$selected_country),
           x = "Category", y = "Average Points") +
      theme_minimal()
  })
  
  
  
  ################Statistics part
  
  ######################################################################################
  # Data Table for Statistics Data Tab
  filteredStatisticsDataData <- reactive({
    final_data_10 %>%
      filter(Tournament == input$statisticsDataTournament,
             Category == input$statisticsDataCategory)
  })
  
  # Server Function for Filtered Data Table with Conditional Column Selection
  output$statisticsDataTable <- renderDT({
    
    # Filtered data excluding "Tournament" and "Category" columns
    filtered_data <- filteredStatisticsDataData() %>%
      select(-Tournament, -Category)
    
    # # Conditional display based on Metric selection
    if (input$statisticsDataMetric == "freq") {
      # Display numeric columns that do NOT end with "PCT", along with "Players" and "Country"
      display_data <- filtered_data %>%
        select(Players, Countries,  where(is.numeric), -ends_with("PCT")) #
    } else if (input$statisticsDataMetric == "PCT") {
      # Display numeric columns that DO end with "PCT", along with "Players" and "Country"
      display_data <- filtered_data %>%
        select(Players, Countries, where(is.numeric), -ends_with("PCT"))
    }
    
    # Render the Data Table with the selected columns
    datatable(display_data,
              options = list(pageLength = 10, autoWidth = TRUE, scrollX = TRUE),
              filter = 'top')
  })
  
  
  ######################################################################################
  # Country Statistics for Statistics Country Statistics
  
  filteredCountryStatsData <- reactive({
    final_data_10 %>%
      filter(Tournament == input$countryStatsTournament,
             Category == input$countryStatsCategory)
  })
  
  # Update the country selection options dynamically based on filtered data
  observe({
    filtered_data <- filteredCountryStatsData()
    
    # Get unique countries from the filtered data
    countries_list <- unique(filtered_data$Countries)
    
    # Add 'All' to the list of countries and set it as the default selection
    countries_list <- c("All", countries_list)
    
    # Update the countries dropdown options
    updateSelectInput(session, "countryStatsCountries", choices = countries_list, selected = "All")
  })
  
  # Reactive expression to filter the data based on selected countries
  filteredDataByCountries <- reactive({
    filtered_data <- filteredCountryStatsData()
    
    selected_countries <- input$countryStatsCountries
    
    #If "All" is selected, update the selected_countries to include all countries from filtered data
    if ("All" %in% selected_countries) {
      selected_countries <- unique(filtered_data$Countries)  # Update to all countries
    }
    
    
    
    # Filter data by the selected countries (now either specific countries or all countries)
    return(filtered_data %>% filter(Countries %in% selected_countries))
  })
  
  # Reactive expression to select comparison parameters based on Metric Type (Frequency or Percentages)
  observe({
    filtered_data <- filteredDataByCountries()
    
    # If Metric Type is "Frequency", select numeric columns that do NOT end with "PCT"
    if (input$countryStatsMetricType == "freq") {
      comparison_columns <- names(filtered_data) %>%
        .[sapply(filtered_data, is.numeric)] %>%
        .[!grepl("PCT$", .)]  # Exclude columns ending with "PCT"
    } else if (input$countryStatsMetricType == "PCT") {
      # If Metric Type is "Percentages", select numeric columns that end with "PCT"
      comparison_columns <- names(filtered_data) %>%
        .[sapply(filtered_data, is.numeric)] %>%
        .[grepl("PCT$", .)]  # Only include columns ending with "PCT"
    }
    
    # Update the Comparison Parameters dropdown with filtered columns
    updateSelectInput(session, "countryStatsComparison", choices = comparison_columns, selected = comparison_columns[1])
  })
  
  
  
  # Server function for rendering the plots
  output$countryStatsPlot <- renderPlot({
    filtered_data <- filteredCountryStatsData()
    
    selected_countries <- input$countryStatsCountries
    
    #If "All" is selected, update the selected_countries to include all countries from filtered data
    if ("All" %in% selected_countries) {
      selected_countries <- unique(filtered_data$Countries)  # Update to all countries
    }
    
    # Subset the data for the selected countries and comparison parameters
    filtered_data <- filtered_data %>%
      filter(Countries %in% selected_countries) %>%
      select(Countries, input$countryStatsComparison)
    
    # Check if one or two comparison parameters are selected
    
    
    if (length(input$countryStatsComparison) == 1) {
      # Plot box plots for comparison parameter
      comparison_param <- input$countryStatsComparison
      
      # Boxplot
      boxplot_plot <- ggplot(filtered_data, aes(x = .data[[comparison_param]], y = Countries)) +
        geom_boxplot(aes(color = Countries), outlier.size = 2, outlier.colour = "red", 
                     width = 0.6, alpha = 0.7) +  # Adjust boxplot width and transparency
        labs(x = comparison_param, y = "Countries") +
        theme_minimal() +
        theme(axis.text.y = element_text(angle = 45, hjust = 1)) +  # Rotate y-axis labels for better readability
        ggtitle(paste("Boxplot for", comparison_param)) +
        theme(legend.position = "bottom")
      
      # Density Plot
      density_plot <- ggplot(filtered_data, aes(x = .data[[comparison_param]], fill = Countries)) +
        geom_density(alpha = 0.3) +  # Add density plot for comparison parameter
        labs(x = comparison_param, y = "Density") +
        theme_minimal() +
        ggtitle(paste("Density Plot for", comparison_param)) +
        theme(legend.position = "bottom")
      
      # Combine boxplot and density plot vertically
      grid.arrange(boxplot_plot, density_plot, ncol = 1)
    }
    else if (length(input$countryStatsComparison) == 2) {
      # Scatter plot with correlation for two parameters
      param1 <- input$countryStatsComparison[1]
      param2 <- input$countryStatsComparison[2]
      
      # Calculate the correlation for each country
      country_correlations <- filtered_data %>%
        group_by(Countries) %>%
        summarise(correlation = cor(.data[[param1]], .data[[param2]], use = "complete.obs"))
      
      # Scatter plot with countries colored by their name
      scatter_plot <- ggplot(filtered_data, aes(x = .data[[param1]], y = .data[[param2]], color = Countries)) +
        geom_point() +
        labs(x = param1, y = param2, title = paste("Scatter Plot between", param1, "and", param2)) +
        theme_minimal()
      
      # Print the scatter plot
      print(scatter_plot)
      
      # Return a table or output displaying the correlation values
      output$countryCorrelationsTable <- renderTable({
        country_correlations %>%
          arrange(desc(correlation))  # Sort countries based on correlation values
      })
    }
  })
  
  
  
  
  ######################################################################################
  # Set Performances for Statistics Individual Statistics
  
  filteredIndividualStatsData <- reactive({
    IndividualStatsData <- final_data_10  # Use final_data_10 as the dataset
    
    # Filter by Tournament (Only 'ss' and 'gp')
    IndividualStatsData <- IndividualStatsData %>%
      filter(Tournament == input$individualStatsTournament,Category == input$individualStatsCategory)
    
    return(IndividualStatsData)
  })
  # 
  # Update Country dropdown dynamically based on the selected Tournament and Category
  observe({
    IndividualStatsData <- filteredIndividualStatsData()
    
    # Get the unique countries after filtering
    countries <- unique(IndividualStatsData$Countries)
    
    # Add 'All' option to the list of countries
    countries <- c("All", countries)
    
    # Update the Country dropdown choices and set "All" as the default
    updateSelectInput(session, "individualStatsCountry", choices = countries) #, selected = "All"
  })
  
  # Update Player dropdown dynamically based on the selected Country
  observe({
    data <- filteredIndividualStatsData()
    selected_country <- input$individualStatsCountry
    
    if (selected_country == "All") {
      # If 'All' is selected for Country, show all players for the filtered data
      players <- unique(data$Players)
    } else {
      # Otherwise, show players from the selected country
      players <- unique(data[data$Countries == selected_country,]$Players)
    }
    
    
    # Format the player names by capitalizing the first letter of each word
    players <- str_to_title(players)
    
    # Update the Player dropdown choices
    updateSelectInput(session, "individualStatsPlayer", choices = players)
  })
  
  # Filtered Individual Stats Data based on Tournament, Category, Country, and Player selections
  filteredIndividualStatsH2HData <- reactive({
    data <- final_H2H_10 %>%
      filter(
        Tournament == input$individualStatsTournament,
        Category == input$individualStatsCategory
      )
    
    # Filter by country if not "All"
    if (input$individualStatsCountry != "All") {
      data <- data %>% filter(Player_Country == input$individualStatsCountry)
    }
    
    # Filter by player if a player is selected
    
    data <- data %>% filter(Players == toupper(input$individualStatsPlayer))
    
    
    data
  })
  
  # Scatter plot for Head-to-Head Performances: Points For vs Points Against per Match
  output$headToHeadPlot <- renderPlotly({
    data <- filteredIndividualStatsH2HData() %>%
      mutate(
        PointsForPerMatch = `Points For` / Matches,
        PointsAgainstPerMatch = `Points Against` / Matches,
        Shape = ifelse(Wins > Losses, "Win", "Loss")
      )
    
    plot <- ggplot(data, aes(
      x = PointsForPerMatch, 
      y = PointsAgainstPerMatch, 
      color = Opponent_Country, 
      shape = Shape,
      text = Opponents  # Adding player name here
    )) +
      geom_point(size = 3) +
      labs(
        title = paste("Rivalries of ",(input$individualStatsPlayer)),
        x = "Points For per Match",
        y = "Points Against per Match") +
      theme_minimal()
    
    ggplotly(plot, tooltip = c("text", "PointsForPerMatch", "PointsAgainstPerMatch", "Opponent_Country"))
  })
  
  # Table displaying the selected player's data (excluding Category and Tournament columns)
  output$playerDataTable <- renderDataTable({
    data <- filteredIndividualStatsH2HData() %>%
      select(-Tournament, -Category)
    
    datatable(data, options = list(pageLength = 10, autoWidth = TRUE))
  })
  
  
  
  ######################################################################################
  # Set Performances for Statistics Individual Statistics
  
  
  
  
  # Render the Set Performance Plot for the selected player
  # output$setPerformancePlot <- renderPlot({
  #   # Get the filtered data for all players
  #   all_players_data <- filteredIndividualStatsData()
  #   
  #   # Calculate normalized percentages for the match patterns
  #   patterns_data <- all_players_data %>%
  #     ungroup() %>%
  #     select(Players, `WW`, `WLW`, `LWW`, `WLL`, `LWL`, `LL`, Matches)
  #   
  #   # Normalize the percentages for all players
  #   patterns_data_normalized <- patterns_data %>%
  #     mutate(
  #       WW_pct = (`WW` / Matches) * 100,
  #       WLW_pct = (`WLW` / Matches) * 100,
  #       LWW_pct = (`LWW` / Matches) * 100,
  #       WLL_pct = (`WLL` / Matches) * 100,
  #       LWL_pct = (`LWL` / Matches) * 100,
  #       LL_pct = (`LL` / Matches) * 100
  #     ) %>%
  #     select(Players, WW_pct, WLW_pct, LWW_pct, WLL_pct, LWL_pct, LL_pct)
  #   
  #   # Scale the data for all players
  #   patterns_data_scaled <- patterns_data_normalized %>%
  #     mutate(
  #       WW_pct = WW_pct / max(WW_pct),
  #       WLW_pct = WLW_pct / max(WLW_pct),
  #       LWW_pct = LWW_pct / max(LWW_pct),
  #       WLL_pct = WLL_pct / max(WLL_pct),
  #       LWL_pct = LWL_pct / max(LWL_pct),
  #       LL_pct = LL_pct / max(LL_pct)
  #     )
  #   
  #   # Reshape the data to long format for plotting
  #   patterns_data_long <- patterns_data_scaled %>%
  #     pivot_longer(cols = ends_with("_pct"), names_to = "Pattern", values_to = "Normalized") %>%
  #     mutate(Pattern = gsub("_pct", "", Pattern))  # Clean up column names
  #   
  #   # Get the filtered data for the selected player
  #   selected_player_data <- patterns_data_long %>%
  #     filter(Players == toupper(input$individualStatsPlayer))
  #   
  #   # Plot the radial plot for the selected player
  #   ggplot(selected_player_data, aes(x = Pattern, y = Normalized, fill = Pattern)) +
  #     geom_bar(stat = "identity") +
  #     coord_polar() +
  #     labs(
  #       title = paste("Normalized Match Pattern for Player:", toupper(input$individualStatsPlayer)),
  #       x = "Pattern",
  #       y = "Normalized Percentage"
  #     ) +
  #     theme_minimal() +
  #     theme(legend.position = "none") +
  #     scale_fill_manual(values = c("red", "blue", "green", "purple", "orange", "yellow"))
  # })
  
  
  output$setPerformancePlot <- renderPlot({
    # Get the filtered data for all players
    all_players_data <- filteredIndividualStatsData()
    
    # Calculate normalized percentages for the match patterns
    patterns_data <- all_players_data %>%
      ungroup() %>%
      select(Players, `WW`, `WLW`, `LWW`, `WLL`, `LWL`, `LL`, Matches)
    
    # Normalize the percentages for all players
    patterns_data_normalized <- patterns_data %>%
      mutate(
        WW_pct = (`WW` / Matches) * 100,
        WLW_pct = (`WLW` / Matches) * 100,
        LWW_pct = (`LWW` / Matches) * 100,
        WLL_pct = (`WLL` / Matches) * 100,
        LWL_pct = (`LWL` / Matches) * 100,
        LL_pct = (`LL` / Matches) * 100
      ) %>%
      select(Players, WW_pct, WLW_pct, LWW_pct, WLL_pct, LWL_pct, LL_pct)
    
    # Scale the data for all players
    patterns_data_scaled <- patterns_data_normalized %>%
      mutate(
        WW_pct = WW_pct / max(WW_pct),
        WLW_pct = WLW_pct / max(WLW_pct),
        LWW_pct = LWW_pct / max(LWW_pct),
        WLL_pct = WLL_pct / max(WLL_pct),
        LWL_pct = LWL_pct / max(LWL_pct),
        LL_pct = LL_pct / max(LL_pct)
      )
    
    # Reshape the data to long format for plotting
    patterns_data_long <- patterns_data_scaled %>%
      pivot_longer(cols = ends_with("_pct"), names_to = "Pattern", values_to = "Normalized") %>%
      mutate(Pattern = gsub("_pct", "", Pattern))  # Clean up column names
    
    # Get the filtered data for the selected player
    selected_player_data <- patterns_data_long %>%
      filter(Players == toupper(input$individualStatsPlayer))
    
    # Plot the radial plot for the selected player
    ggplot(selected_player_data, aes(x = Pattern, y = Normalized, fill = Pattern)) +
      geom_bar(stat = "identity") +
      coord_polar(start = 0) +  # Start the polar plot from the top
      labs(
        title = paste("Scaled Match Performance of Player:", (input$individualStatsPlayer)),
        x = "Pattern",
        y = "Normalized Percentage"
      ) +
      theme_minimal() +
      theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1)) +  # Adjust x-axis text
      scale_fill_manual(values = c("red", "blue", "green", "purple", "orange", "yellow")) +
      theme(
        plot.margin = margin(10, 10, 10, 10)  # Increase plot margins to avoid margin issues
      )
  })
  
  
  # Render the data table for the selected player's performance
  output$setPerformanceDataTable <- renderDataTable({
    # Get the filtered data for the selected player
    all_players_data <- filteredIndividualStatsData()
    
    # Filter out the specific player data for the table
    player_data <- all_players_data %>%
      filter(Players == toupper(input$individualStatsPlayer))
    
    # Remove the unnecessary columns like 'Category' and 'Tournament'
    player_data_clean <- player_data %>%
      select(-Category, -Tournament)
    
    # Return the cleaned data table
    datatable(player_data_clean, options = list(pageLength = 5))
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
